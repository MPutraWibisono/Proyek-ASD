import pandas as pd
import math
import os
import pwinput
import sys
from csv import DictWriter
from prettytable import PrettyTable

x = PrettyTable()

#HEADER-------------------------------------------------------------------------
x.field_names = ["Program Pertanian"]
x.add_row(["\"MEMBANTU PETANI LOKAL MAJU!\""])
#LINKED LIST===============================================================================
class Node1:
    def __init__(self,isi):
        self._isi = isi
        self._next = None
        
class LL:
    def __init__(self):
        self._head = None
        self._tail = None
        
    def add1(self,isi):
        a=Node1(isi)
        if self._head == None:
            self._head = a
            self._tail = a
        else:
            a._next = self._head
            self._head = a
            
    def add2(self,isi):
        a=Node1(isi)
        if self._tail == None:
            self._head = a
            self._tail = a
        else:
            self._tail._next = a
            self._tail = a
        
    def cetak(self):
            a=self._head
            keranjang[index]=[]
            while a != None:
                print(a._isi,"->",end=" ")
                keranjang[index].append(a._isi)
                a=a._next
            print(a)

    def zero(self):
        if self._head != None:
            self._head = self._tail._next

myLL = LL()

#QUEUE===============================================================================
class Node2: 
    def __init__(self, data): 
        self.data = data  
        self.next = None  
        self.prev = None 
  
class Queue: 
    def __init__(self): 
        self.head = None
        self.last = None
 
    def enqueue(self, data): 
        if self.last is None: 
            self.head =Node2(data) 
            self.last =self.head 
        else: 
            self.last.next = Node2(data) 
            self.last.next.prev=self.last 
            self.last = self.last.next

    def dequeue(self):
        global b
        try:
            if self.head is None: 
                return None
            else:
                temp= self.head.data 
                self.head = self.head.next
                self.head.prev=None
                keranjang[b].pop(keranjang[b].index(temp))
        except:
            keranjang[b].pop(keranjang[b].index(temp))
            self.head = None
            self.last = None
        return temp

    def printqueue(self):  
        temp=self.head 
        while temp is not None: 
            print(temp.data,end="->") 
            temp=temp.next
        print(temp)
    
    def free(self):
        if self.head is None: 
            return None
        else: 
            self.head = self.head.prev
            self.last = self.last.next

queue = Queue() 

# # #===============================================================================

# #FUNGSI--------------------------------------------------------------------------------------------------
def log():
    os.system('cls')
    print(x)
    global logreg
    logreg=input("""
            +======+
     :::::::[ HOME ]::::::::
    |=======================|
 1->|  REGISTER(USER BARU)  |
 2->|        LOGIN          |
 3->|         EXIT          |
    |=======================|

Selamat Datang, ada yang bisa dibantu?
sesuai nomor>> """)
    os.system('cls')

def regis():
    tambahAkun()
    os.system('cls')
    print (" Buat Akun Baru ".center (25,'='))
    while True:
        new_user = str.strip(input ("Masukan username: ").replace (" ",""))
        if new_user in dataUser.get("User") or new_user in dataAdmin.get("User"):
            os.system('cls')
            print ("Username sudah terpakai\nSilahkan coba lagi\n")
        elif new_user == "":
            os.system('cls')
            print ("Nama tidak boleh kosong")
        else:
            new_pass = str.strip(pwinput.pwinput("Masukan password baru: ").replace (" ",""))
            ulang_pass = str.strip(pwinput.pwinput("Konfirmasi password: ").replace (" ",""))
            if new_pass == "" and ulang_pass == "":
                os.system('cls')
                print ("Kata Sandi tidak boleh kosong\nSilahkan coba lagi")
            else:
                if new_pass == ulang_pass:
                    dataUser.get("User").append(new_user)
                    dataUser.get("Sandi").append(new_pass)
                    index = dataUser.get("User").index(new_user)
                    keranjang[index]=[]
                    d = open('dataUser.csv', 'a', newline='')
                    w = DictWriter(d,fieldnames =["User","Sandi"])
                    w.writerow({"User": new_user, "Sandi": new_pass})
                    d.close()
                    print (f"\n{dataUser.get ('User')[-1]}, kamu berhasil membuat akun")
                    input ("Tekan ENTER untuk lanjut")
                    os.system('cls')
                    break
                else:
                    os.system('cls')
                    print ("Konfirmasi password salah.\n")

def login(us,admin):
    tambahAkun()
    global j
    global index
    nama=str.strip(input("Login User\nMasukkan Nama User : ").replace (" ",""))
    pas=str.strip(pwinput.pwinput("Masukkan Password : ").replace (" ",""))
    os.system('cls')
    try:
    #AKTIVITAS ADMIN=========================================================
        if nama in admin["User"] and pas == admin["Sandi"][admin["Sandi"].index(pas)]:
            index = admin["User"].index(nama)
            j=0
            keranjangi()
            menuAdmin()
    #AKTIVITAS USER==========================================================
        elif nama in us["User"] and pas == us["Sandi"][us["Sandi"].index(pas)]:
            index = us["User"].index(nama)
            print("\nWelcome Aboard,", nama, "\b!")
            j=0
            keranjangi()
            menuUser()
        elif nama == "" or pas == "":
            os.system('cls')
            print ("\nTidak boleh kosong")
        else:
            if j==2:
                j += 1
                print(f"{j}/3kesempatan")
            elif j<2:
                j += 1
                print(f"\nUlangi Lagi, Salah password! {j} dari 3 kesempatan")
    except ValueError:
        if j==2:
            j += 1
            print(f"{j}/3kesempatan")
        elif j<2:
            j += 1
            print(f"\nUlangi Lagi! {j} dari 3 kesempatan")

def menuUser():
    global y
    while True:
        menu=input("""
    |=======================|
 1->|       AKUN SAYA       |
 2->|       KOMODITAS       |
 3->|         BACK          |
    |=======================|

sesuai nomor>> """)
        if menu == "1":
            os.system('cls')
            akun()
        elif menu == "2":
            os.system('cls')
            komo()
        elif menu == "3":
            y=0
            os.system('cls')
            break
        else:
            os.system('cls')
            pass

def menuAdmin():
    global y
    while True:
        os.system('cls')
        menu=input("""
    |=======================|
 1->|       DATA USER       |
 2->|       KOMODITAS       |
 3->|         BACK          |
    |=======================|

sesuai nomor>> """)
        if menu == "1":
            os.system('cls')
            akunAdmin()
        elif menu == "2":
            os.system('cls')
            pertanian()
        elif menu == "3":
            y=0
            break
        else:
            pass

def akun():
    menuB=input("""
    |=======================|
 1->|      LIHAT AKUN       |
 2->|     UBAH PASSWORD     |
    |=======================|

sesuai nomor>> """)
    if menuB == "1":
        os.system('cls')
        print(f'\nnama : {dataUser["User"][index]}, password : {dataUser["Sandi"][index]}\n')
        input("Tekan ENTER untuk lanjut")
        os.system('cls')
    elif menuB == "2":
        os.system('cls')
        pass1=str.strip(input("Masukkan Password Lama : ").replace (" ",""))
        newPass=str.strip(pwinput.pwinput("Masukkan Password Baru : ").replace (" ",""))
        if pass1 == dataUser["Sandi"][index]:
            dataUser["Sandi"][index] = newPass
            df = pd.read_csv("dataUser.csv")
            df.loc[index, 'Sandi'] = newPass
            df.to_csv("dataUser.csv", index=False)
            print("\n(PASSWORD BERHASIL DIUBAH !)\n")
            input("Tekan ENTER untuk lanjut")
        elif pass1 == "" or newPass == "":
            os.system('cls')
            print ("Tidak boleh kosong")
        else:
            print("\nGagal mengubah")
        os.system('cls')
    else:
        os.system('cls')
        pass

def akunAdmin():
    while True:
        menuD=input("""
    |=======================|
 1->|      LIHAT DATA       |
 2->|      HAPUS DATA       |
 3->|         BACK          |
    |=======================|

sesuai nomor>> """)
        if menuD == "1":
            os.system('cls')
            x.clear()
            x.field_names = ["No","User"]
            for i in range(len(dataUser["User"])):
                x.add_row([i+1,dataUser["User"][i]])
            x.align = "l"
            print(x)
            input("Tekan ENTER untuk lanjut")
            os.system('cls')
        elif menuD == "2":
            os.system('cls')
            del1=str.strip(input("Masukkan Username yang ingin dihapus : ").replace (" ",""))
            if del1 in dataUser["User"]:
                fe = pd.read_csv('dataUser.csv')
                global ind
                ind=dataUser["User"].index(del1)
                dataUser["User"].pop(ind)
                dataUser["Sandi"].pop(ind)
                keranjangi()
                ranjang()
                keranjang.pop(ind)
                fe = fe.drop(ind)
                fe.to_csv("dataUser.csv", index=False)
                print("\n(USERNAME DAN PASSWORD BERHASIL DIHAPUS !)\n")
                input("Tekan ENTER untuk lanjut")
                os.system('cls')
            elif del1 == "":
                os.system('cls')
                print ("Tidak boleh kosong")
            else:
                print("Username tersebut tidak ditemukan")
        elif menuD == "3":
            break
        else:
            pass

def komo():
    while True:
        print("Pesanan saya :",keranjang[index])
        menuA=input("""
    |=======================|
 1->|    LIHAT KOMODITAS    |
 2->|    CARI  KOMODITAS    |
 3->|    PESAN KOMODITAS    |
 4->|         BACK          |
    |=======================|

sesuai nomor>> """)
        if menuA == "1":
            os.system('cls')
            lihat()
            input("Tekan ENTER untuk lanjut")
            os.system('cls')
        elif menuA == "2":
            cari()
            input("Tekan ENTER untuk lanjut")
            os.system('cls')
        elif menuA == "3":
            pesan()
        elif menuA == "4":
            os.system('cls')
            break
        else:
            os.system('cls')
            pass

def pertanian():
    while True:
        menuE=input("""
    |=======================|
 1->|     DATA KOMODITAS    |
 2->|        PESANAN        |
 3->|         BACK          |
    |=======================|

sesuai nomor>> """)
        if menuE == "1":
            os.system('cls')
            komoditi()
        elif menuE == "2":
            pesanan()
        elif menuE == "3":
            break
        else:
            pass

def komoditi():
    while True:
        os.system('cls')
        menuA=input("""
    |=======================|
 1->|    LIHAT KOMODITAS    |
 2->|    URUT  KOMODITAS    |
 3->|    CARI  KOMODITAS    |
 4->|    TAMBAH KOMODITAS   |
 5->|    HAPUS KOMODITAS    |
 6->|         BACK          |
    |=======================|

sesuai nomor>> """)
        if menuA == "1":
            os.system('cls')
            lihat()
            input("Tekan ENTER untuk lanjut")
        elif menuA == "2":
            sort()
            input("Tekan ENTER untuk lanjut")
        elif menuA == "3":
            cari()
            input("Tekan ENTER untuk lanjut")
        elif menuA == "4":
            tambah()
            input("Tekan ENTER untuk lanjut")
        elif menuA == "5":
            hapus()
            input("Tekan ENTER untuk lanjut")
        elif menuA == "6":
            break
        else:
            pass

def sort():
    os.system('cls')
    tambahData()
    a=hasilAlam["Harga"]
    b=hasilAlam["Stok"]
    c=hasilAlam["Petani"]
    d=[]
    for i in hasilAlam["Komoditas"]:
        d.append(i)
    while True:
        global sorti
        sorti=input("""
        LIHAT BERDASARKAN
    |===========================|
 1->|  (asc)KECIL - BESAR / A-Z |
 2->|  (desc)BESAR - KECIL/ Z-A |
    |===========================|

sesuai nomor>> """)
        so=mergeSort(hasilAlam["Komoditas"], ascending = True)
        if sorti == "1":
            x.clear()
            x.field_names = ["NO","KOMODITAS","HARGA /Kg","STOK (Kg)","PETANI"]
            for i in so:
                x.add_row([so.index(i)+1,i,a[d.index(i)],b[d.index(i)],c[d.index(i)]])
                d[d.index(i)]=d[d.index(i)][:3]
            x.align = "l"
            print(x)
            break
        elif sorti == "2":
            x.clear()
            x.field_names = ["NO","KOMODITAS","HARGA/Kg","STOK (Kg)","PETANI"]
            for i in so:
                x.add_row([so.index(i)+1,i,a[d.index(i)],b[d.index(i)],c[d.index(i)]])
                d[d.index(i)]=d[d.index(i)][:3]
            x.align = "l"
            print(x)
            break
        else:
            break

def lihat():
    tambahData()
    x.clear()
    x.field_names = ["NO","KOMODITAS","HARGA /Kg","STOK (Kg)","PETANI"]
    for i in range(len(hasilAlam["Komoditas"])):
        x.add_row([i+1,hasilAlam["Komoditas"][i],hasilAlam["Harga"][i],hasilAlam["Stok"][i],hasilAlam["Petani"][i]])
    x.align = "l"
    print(x)

def cari():
    os.system('cls')
    tambahData()
    a=hasilAlam["Harga"]
    b=hasilAlam["Stok"]
    c=hasilAlam["Petani"]
    d=[]
    for i in hasilAlam["Komoditas"]:
        d.append(i)
    while True:
        sea=input("Masukkan data yang ingin dicari :").title()
        if sea in hasilAlam["Komoditas"]:
            global sorti
            sorti ="1"
            sortt=mergeSort(hasilAlam["Komoditas"], ascending = True)
            for i in range(len(sortt)):
                if i == int(jumpSearch(sortt,sea,len(sortt))):
                    print(f"\n--Setelah disorting asc--\n{sea} berada di index {i} urutan {i+1}")
                    for l in range(len(d)):
                        if d[l]==sortt[i]:
                            print(f"Harga           : Rp.{a[l]}/kg")
                            print(f"Stok (tersedia) : {b[l]} kg")
                            print(f"Diurus oleh     : {c[l]}")
                            sortt[i]=sortt[i][:3]
                            d[l]=d[l][:3]
                            break
        elif sea == "" or sea == " ":
            os.system('cls')
            print ("Tidak boleh kosong")
        else:
            print("Data yang ingin dicari tidak ditemukan!")
        break

def pesan():
    os.system('cls')
    tambahData()
    mesanAuto()
    print(keranjang[index])
    tanda = -1
    while True:
        lihat()
        try:
            mes=int(input("Ingin memesan apa, berikan kami Nomornya!\n=> "))
            if mes > 0:
                mes-=1
                if tanda == -1 or tanda != mes:
                    if hasilAlam["Komoditas"][mes] == hasilAlam["Komoditas"][mes]:
                        if hasilAlam["Komoditas"][mes] in keranjang[index]:
                            print("Maaf, anda sudah memesan komoditas ini..")
                            input ("Tekan ENTER untuk lanjut")
                            myLL.zero()
                            break
                        else:
                            lg=str.strip(input("Prioritas atau tidak? y/n\n<>")).replace (" ","")
                            print("Jika pesanan pertama, ketikan 'y'!!")
                            if lg =="y":
                                myLL.add1(hasilAlam["Komoditas"][mes])
                                tanda = mes
                            elif lg=="n":
                                myLL.add2(hasilAlam["Komoditas"][mes])
                                tanda = mes
                            elif lg == "":
                                os.system('cls')
                                print ("Nama tidak boleh kosong")
                                myLL.zero()
                                break
                            else:
                                os.system('cls')
                                print ("Input Salah")
                                myLL.zero()
                                break
                            tanya=input("Ingin memesan lagi? ('y' untuk lanjut memesan)\n<>").lower()
                            if tanya == "y":
                                os.system('cls')
                                continue
                            else:
                                pass
                        myLL.cetak()
                        os.system('cls')
                        print("Pesanan saya :",keranjang[index])
                        myLL.zero()  
                        break
                    else:
                        print("DATA TIDAK ADA!")
                        myLL.zero()
                        break
                elif tanda == mes:
                    print("Maaf, anda sudah memesan komoditas ini..")
                    input ("Tekan ENTER untuk lanjut")
                    os.system('cls')
                    myLL.zero()
                    break
            else:
                    print("DATA TIDAK ADA!")
                    myLL.zero()
                    break
        except :
            print("DATA TIDAK ADA!")
            myLL.zero()
            break

def mesanAuto():
    for i in reversed(keranjang[index]):
        myLL.add1(i)

def pesanan():
    global b
    try:
        os.system('cls')
        for x in list(keranjang.keys()):
            print("\n>_ User",dataUser["User"][x],"_<\n")
            for i in keranjang[x]:
                queue.enqueue(i) 
            queue.printqueue()
            queue.free()
        pes=str.strip(input("\n__User yang ingin dikonfirmasi \n->")).replace (" ","")
        if pes == "" or pes==" ":
            os.system('cls')
            print ("User tidak boleh kosong")
        elif pes in dataUser["User"]:
            os.system('cls')
            global b
            b = dataUser["User"].index(pes)
            print("\n>User",dataUser["User"][b],"\n")
            for i in keranjang[b]:
                queue.enqueue(i)
            queue.dequeue()
            queue.printqueue()
            queue.free()
            print("\nBerhasil di konfirmasi!")
            input("Tekan ENTER untuk lanjut")
            os.system('cls')
        else:
            print("Input Salah")
    except:
        os.system('cls')
        print("Salah Input")

def tambahAkun():
    fe = pd.read_csv('dataUser.csv')
    a1=fe["User"]
    b1=fe["Sandi"]
    for m in list(dataUser.keys()):
        dataUser[m]=[]
    for b in range(len(fe)):
        dataUser["User"].append(a1[b])
        dataUser["Sandi"].append(b1[b])
    else:
        pass
# ---------------------------------------
    fe1 = pd.read_csv('dataAdmin.csv')
    a2=fe1["User"]
    b2=fe1["Sandi"]
    for m in list(dataAdmin.keys()):
        dataAdmin[m]=[]
    for b in range(len(fe1)):
        dataAdmin["User"].append(a2[b])
        dataAdmin["Sandi"].append(b2[b])
    else:
        pass

def tambahData():
    fe = pd.read_csv('hasilAlam.csv')
    a1=fe["Harga"]
    b1=fe["Stok"]
    c1=fe["Petani"]
    d1=fe["Komoditas"]
    if idx == True:
        for z in list(hasilAlam.keys()):
            hasilAlam[z]=[]
        for i in range(len(fe)):
            hasilAlam["Komoditas"].append(d1[i])
            hasilAlam["Harga"].append(a1[i])
            hasilAlam["Stok"].append(b1[i])
            hasilAlam["Petani"].append(c1[i])
    elif hasilAlam["Komoditas"] == []:
        for i in range(len(fe)):
            hasilAlam["Komoditas"].append(d1[i])
            hasilAlam["Harga"].append(a1[i])
            hasilAlam["Stok"].append(b1[i])
            hasilAlam["Petani"].append(c1[i])
    else:
        pass

def tambah():
    os.system('cls')
    try:
        tmbh = input("| Masukkan Nama Komoditas : ").title()
        harga = int(input("| Masukkan Harga Komoditas(/kg) : "))
        stok = int(input("| Masukkan Stok Komoditas(kg) : "))
        isinstance(harga, int)
        isinstance(stok, int)
        petani = input("| Masukkan Nama Petani : ").title()
        if tmbh == "" or petani == "" or tmbh == " " or petani == " ":
            os.system('cls')
            print ("Nama tidak boleh kosong")
        if harga >= 1000 or stok >= 1000:
            d = open('hasilAlam.csv', 'a', newline='')
            w = DictWriter(d,fieldnames =["Komoditas","Harga","Stok","Petani"])
            w.writerow({'Komoditas': tmbh, 'Harga': harga, 'Stok': stok, 'Petani': petani})
            d.close()
            global idx
            idx=True
            print("\nDATA BERHASIL DITAMBAH")
    except:
        print("\n!!! Input Salah !!!\n")

def hapus():
    os.system('cls')
    lihat()
    try:
        fe = pd.read_csv('hasilAlam.csv')
        hapuss= int(input("Masukkan No Komoditas yang ingin dihapus\n-> "))
        isinstance(hapuss, int)
        if hapuss > 0:
            hapuss-= 1
            fe = fe.drop(hapuss)
            fe.to_csv("hasilAlam.csv", index=False)
            global idx
            idx = True
            print("\nDATA BERHASIL DIHAPUS")
        else:
            pass
    except:
        print("\n!!! Input Salah !!!\n")

def keranjangi():
    try:
        if keranjang[index]!=[]:
            pass
        else:
            pass
    except:
        keranjang[index]=[]
        
def ranjang():
    try:
        if keranjang[ind]!=[]:
            pass
    except:
        keranjang[ind]=[]

def mergeSort(L, ascending = True):
    result = []  
    if len(L) == 1:
        return L  
    tengah = len(L) // 2
    bagian1 = mergeSort(L[:tengah])
    bagian2 = mergeSort(L[tengah:])

    x, y = 0, 0
    while x < len(bagian1) and y < len(bagian2):
        if sorti == "1":
            if bagian1[x] > bagian2[y]: #(> u/ ascending)
                result.append(bagian2[y])
                y = y + 1
            else:
                result.append(bagian1[x])
                x = x + 1
        elif sorti == "2":
            if bagian1[x] < bagian2[y]: #(< u/ descending)
                result.append(bagian2[y])
                y = y + 1
            else:
                result.append(bagian1[x])
                x = x + 1

    result = result + bagian1[x:]
    result = result + bagian2[y:]
    if ascending == True :
        return result
    else:
        result.reverse()
        return result

def jumpSearch( arr , x , n ):
    step = math.sqrt(n)
    prev = 0
    while arr[int(min(step, n)-1)] < x:
        prev = step
        step += math.sqrt(n)
        if prev >= n:
            return -1
    while arr[int(prev)] < x:
        prev += 1
        if prev == min(step, n):
            return -1
    if arr[int(prev)] == x:
        return prev
    return -1

#MAIN------------------------------------------------------------------------
dataUser = {"User"  :[],
            "Sandi" :[]}
dataAdmin={"User"  :[],
            "Sandi" :[]}
hasilAlam ={"Komoditas" : [],
            "Harga" : [],
            "Stok"  : [],
            "Petani": []}
keranjang= {}

idx =False

def main():
    global j
    global y
    j=0
    y=0
    while True:
        if j==3:
            print("Coba lagi lain kali ;)")
            break
        else:
            if y==0:
                log()
            else:
                pass
            y+=1
        #REGISTRASI==========================================================
            if logreg =="1":
                y=0
                os.system('cls')
                regis()
        #LOGIN===============================================================
            elif logreg =="2":
                login(dataUser,dataAdmin)
        #EXIT================================================================
            elif logreg =="3":
                print("Selamat Beraktivitas!!")
                sys.exit()
        #SALAH INPUT HOME====================================================
            else:
                y=0
                print("Ulangi lagi!")

main()